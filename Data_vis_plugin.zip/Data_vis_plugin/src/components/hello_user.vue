<script setup>
  
defineProps({
  msg: {
    type: String,
    required: true
  }
});

import LineChart from './charts.vue'

</script>

<template>
  <div class="BigPurp">
    <div class="HeaderText">
      <h1>Hello, {{ msg }}!</h1>
      <p class="SearchTrends">Here are your search trends for the last week:</p>
    </div>
    <div class="MetricData">
      <LineChart/>
    </div>
    <div class="metrics">
      <div class="metric_info">
          <img src="C:\Users\ljdde\OneDrive\Desktop\UROP (sharot)\brain.png" alt="green brain" class='metric_image'>
          <p class="metric_text">The knowledge value indicates whether the information on the webpage is likely to increase your understanding of its topic</p>
      </div>
      <div class="metric_info">
        <img src="C:\Users\ljdde\OneDrive\Desktop\UROP (sharot)\happy_face.png" alt="happy face" class="metric_image">
        <p class="metric_text">The emotion value indicates whether the informatioin on the webpage is likely to increase your understanding of its topic</p>
      </div>
      <div class="metric_info">
        <img src="C:\Users\ljdde\OneDrive\Desktop\UROP (sharot)\wrench.png" alt="wrench" class="metric_image">
        <p class="metric_text">The actionability value indicates whether the information on the webpage is likely to help guide your actions and/or decisions</p>
      </div>
    </div>
  </div>
</template>

<style scoped>


.BigPurp{
    background-color: rgb(40,60,80);
    height:100%;
    width:100%;
}

.HeaderText{
  padding-top:5%;
  padding-left:9%
}

h1{
    font-size: 32pt;
    color: white;
}

.SearchTrends{
    font-size:11pt;
    color:white
}

.MetricData{
  height:35%;
  width:80%;
  margin-left:10%;
  margin-right:10%;
  margin-top:5%;
  margin-bottom:5%
}

.metrics{
  display:flex;
  position:relative;
  justify-content: space-evenly;
  width: 80%;
  margin-left:10%;
  margin-right:10%
}

.metric_info{
  width:30%;
  align-items:center
}

.metric_image{
  width:65%;
  margin-left:17.5%;
  margin-right:17.5%
}

.metric_text{
  text-align:center
}





</style>
