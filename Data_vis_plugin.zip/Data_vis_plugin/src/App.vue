<script setup>

import hello_user from './components/hello_user.vue'
import Sidebar from './components/Sidebar.vue'

</script>

<template>
  <div class="page">
    <div class="left_side">
      <Sidebar/>
    </div>
    <div class="right_side">
      <hello_user msg="LuckyDeignan"/>
    </div>
  </div>

 
</template>

<style scoped>



.page{
  background-color: aqua;
  min-height:200%;
  display:flex;
  flex-direction: row;
  bottom:0px
}



    


.left_side {
    display: fixed;
    place-items: flex-start;
    height: 150vh;
    width: 20%;
    top: 0;
    left: 0;
    background-color: #111;
    
}


.right_side{
    float:right;
    height: 150vh;
    width: 80%;
    bottom:0
}
</style>
