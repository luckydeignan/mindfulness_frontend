import { Colors } from "chart.js"

export const data = {
    labels: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
    datasets: [
      {
        label: 'Knowledge',
        backgroundColor: '#0D5FCE', 
        borderColor: '#0D5FCE',
        data: [78, 63, 63, 77, 78, 82, 83],
      },
      {
        label: 'Emotion',
        backgroundColor: '#f1c40f',
        borderColor:'#f1c40f', 
        data: [45, 39, 10, 40, 39, 80, 40]
      },
      {
        label: 'Actionability',
        backgroundColor: '#2CE93F', 
        borderColor:'#2CE93F', 
        data: [30, 70, 15, 32, 69, 39, 54]
      }
    ]
  }
  
  export const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins:{
      legend:{
        fontColor: 'white',
        labels: {
        color: 'white'
          }
        }
      },
    scales:{
      x:{
        ticks:{
          color:'white'
        }
      },
      y:{
        ticks:{
          color:'white'
        }
      }
    }
}