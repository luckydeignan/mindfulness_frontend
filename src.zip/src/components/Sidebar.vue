<script setup>
defineProps({
  msg: {
    type: String,
    required: true
  }
})


  
</script>

<template>
  <div class="sidebar_logged_in centered">
  <div class="AllDaButtons">
    <button>Home</button>
    <button>Knowledge</button>
    <button>Emotion</button>
    <button>Actionability</button>
    <button>Settings</button>
    <button id="LogOut">Log Out</button>
  </div>
  </div>
  
  <div class="sidebar_logged_out">
    
  </div>
</template>

<style scoped>



.centered button {
    display: inline-block;
    margin-left: 7.5%;
    margin-right:7.5%;
    margin-top:7.5%;
    padding: 1em;
    position: relative;
    top: 1em;
    width:85%;
    font-family: sans-serif;
    color: white ;
    background-color: rgb(60,60,90);
    font-size: 10pt;
    border-style:solid;
    border-color:rgb(50,50,50)
    
}

.AllDaButtons{
  width:100%;
  height:90%;
  margin-top:10%

}

#LogOut {
  background-color: rgb(165,60,60);

}

.sidebar_logged_in {
    background-color: rgb(119, 125, 141) ;
    width: 100%;
    height: 100%;
    display:flex;
    flex-direction:column;
    align-items:center;

}


</style>
